#include "person.h"

//Person::Person()
//{

//}
