#ifndef OVERLOAD2_H
#define OVERLOAD2_H
#include <QtCore>
#include "person.h"

#endif // OVERLOAD2_H
